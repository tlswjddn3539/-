
  # Housing Product Inspection Program

  This is a code bundle for Housing Product Inspection Program. The original project is available at https://www.figma.com/design/uLWtIXjpEtLVo5OWjHlEDg/Housing-Product-Inspection-Program.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  