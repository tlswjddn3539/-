import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { InspectionUpload } from './components/InspectionUpload';
import { InspectionHistory } from './components/InspectionHistory';
import { Dashboard } from './components/Dashboard';
import { Camera, History, BarChart3 } from 'lucide-react';

interface DefectType {
  name: string;
  severity: 'high' | 'medium' | 'low';
  location: string;
  confidence: number;
}

interface InspectionResult {
  id: string;
  timestamp: Date;
  imageName: string;
  imageUrl: string;
  status: 'pass' | 'fail';
  defects: DefectType[];
  overallScore: number;
}

export default function App() {
  const [inspectionHistory, setInspectionHistory] = useState<InspectionResult[]>([]);
  const [activeTab, setActiveTab] = useState('inspection');

  const handleInspectionComplete = (result: InspectionResult) => {
    setInspectionHistory(prev => [result, ...prev]);
  };

  const handleClearHistory = () => {
    if (window.confirm('모든 검사 이력을 삭제하시겠습니까?')) {
      setInspectionHistory([]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* 헤더 */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            하우징 제품 불량 검사 시스템
          </h1>
          <p className="text-gray-600">
            AI 기반 자동 불량 검사 및 품질 관리 시스템
          </p>
        </div>

        {/* 탭 네비게이션 */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="inspection" className="flex items-center gap-2">
              <Camera className="w-4 h-4" />
              검사
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <History className="w-4 h-4" />
              이력
            </TabsTrigger>
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              통계
            </TabsTrigger>
          </TabsList>

          <TabsContent value="inspection" className="space-y-4">
            <InspectionUpload onInspectionComplete={handleInspectionComplete} />
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            <InspectionHistory 
              history={inspectionHistory}
              onClearHistory={handleClearHistory}
            />
          </TabsContent>

          <TabsContent value="dashboard" className="space-y-4">
            <Dashboard history={inspectionHistory} />
          </TabsContent>
        </Tabs>

        {/* 푸터 */}
        <div className="mt-12 pt-6 border-t text-center text-sm text-gray-500">
          <p>하우징 제품 불량 검사 시스템 v1.0 | 대학교 과제용 프로그램</p>
        </div>
      </div>
    </div>
  );
}
