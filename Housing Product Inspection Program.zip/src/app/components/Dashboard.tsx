import { BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { TrendingUp, TrendingDown, Activity, AlertTriangle } from 'lucide-react';

interface DefectType {
  name: string;
  severity: 'high' | 'medium' | 'low';
  location: string;
  confidence: number;
}

interface InspectionResult {
  id: string;
  timestamp: Date;
  imageName: string;
  imageUrl: string;
  status: 'pass' | 'fail';
  defects: DefectType[];
  overallScore: number;
}

interface DashboardProps {
  history: InspectionResult[];
}

export function Dashboard({ history }: DashboardProps) {
  if (history.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>통계 대시보드</CardTitle>
          <CardDescription>검사 데이터가 없습니다</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-12 text-gray-500">
            <Activity className="w-16 h-16 mb-4" />
            <p>검사를 시작하면 통계가 표시됩니다</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // 통계 계산
  const totalInspections = history.length;
  const passCount = history.filter(h => h.status === 'pass').length;
  const failCount = totalInspections - passCount;
  const passRate = ((passCount / totalInspections) * 100).toFixed(1);
  const avgScore = (history.reduce((sum, h) => sum + h.overallScore, 0) / totalInspections).toFixed(1);

  // 불량 유형별 통계
  const defectStats: { [key: string]: number } = {};
  history.forEach(item => {
    item.defects.forEach(defect => {
      defectStats[defect.name] = (defectStats[defect.name] || 0) + 1;
    });
  });

  const defectChartData = Object.entries(defectStats).map(([name, count]) => ({
    name: name.split(' ')[0],
    count,
    fullName: name
  })).sort((a, b) => b.count - a.count);

  // 합격/불합격 비율
  const statusData = [
    { name: '합격', value: passCount, color: '#22c55e' },
    { name: '불합격', value: failCount, color: '#ef4444' }
  ];

  // 시간별 검사 추이 (최근 10개)
  const recentInspections = history.slice(-10).map((item, index) => ({
    index: index + 1,
    name: `#${index + 1}`,
    score: item.overallScore,
    status: item.status
  }));

  // 심각도별 통계
  const severityStats = {
    high: 0,
    medium: 0,
    low: 0
  };
  history.forEach(item => {
    item.defects.forEach(defect => {
      severityStats[defect.severity]++;
    });
  });

  const severityData = [
    { name: '높음', value: severityStats.high, color: '#ef4444' },
    { name: '중간', value: severityStats.medium, color: '#eab308' },
    { name: '낮음', value: severityStats.low, color: '#3b82f6' }
  ];

  return (
    <div className="space-y-6">
      {/* 요약 카드 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>총 검사 건수</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-3xl font-bold">{totalInspections}</span>
              <Activity className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>합격률</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-3xl font-bold text-green-600">{passRate}%</span>
              <TrendingUp className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>평균 점수</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-3xl font-bold">{avgScore}</span>
              {parseFloat(avgScore) >= 70 ? (
                <TrendingUp className="w-8 h-8 text-green-500" />
              ) : (
                <TrendingDown className="w-8 h-8 text-red-500" />
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>총 불량 건수</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-3xl font-bold text-red-600">{failCount}</span>
              <AlertTriangle className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 차트 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* 합격/불합격 비율 */}
        <Card>
          <CardHeader>
            <CardTitle>합격/불합격 비율</CardTitle>
            <CardDescription>전체 검사 결과 분포</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}건`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* 불량 유형별 통계 */}
        {defectChartData.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>불량 유형별 통계</CardTitle>
              <CardDescription>검출된 불량 유형 분포</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={defectChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip 
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-white p-3 border rounded shadow-lg">
                            <p className="font-semibold">{payload[0].payload.fullName}</p>
                            <p className="text-sm">건수: {payload[0].value}</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="count" fill="#ef4444" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* 검사 점수 추이 */}
        <Card>
          <CardHeader>
            <CardTitle>검사 점수 추이</CardTitle>
            <CardDescription>최근 검사 결과</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={recentInspections}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="score" 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  name="점수"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* 심각도별 분포 */}
        {(severityStats.high + severityStats.medium + severityStats.low) > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>불량 심각도 분포</CardTitle>
              <CardDescription>불량의 심각도별 통계</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={severityData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => value > 0 ? `${name}: ${value}건` : ''}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {severityData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
