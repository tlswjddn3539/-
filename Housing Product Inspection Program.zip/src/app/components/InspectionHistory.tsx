import { CheckCircle, XCircle, Trash2, Download } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';

interface DefectType {
  name: string;
  severity: 'high' | 'medium' | 'low';
  location: string;
  confidence: number;
}

interface InspectionResult {
  id: string;
  timestamp: Date;
  imageName: string;
  imageUrl: string;
  status: 'pass' | 'fail';
  defects: DefectType[];
  overallScore: number;
}

interface InspectionHistoryProps {
  history: InspectionResult[];
  onClearHistory: () => void;
}

export function InspectionHistory({ history, onClearHistory }: InspectionHistoryProps) {
  const exportToCSV = () => {
    if (history.length === 0) return;

    const headers = ['ID', '일시', '이미지명', '상태', '점수', '불량 개수', '불량 유형'];
    const rows = history.map(item => [
      item.id,
      item.timestamp.toLocaleString('ko-KR'),
      item.imageName,
      item.status === 'pass' ? '합격' : '불합격',
      item.overallScore,
      item.defects.length,
      item.defects.map(d => d.name).join('; ')
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `inspection_history_${new Date().getTime()}.csv`;
    link.click();
  };

  if (history.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>검사 이력</CardTitle>
          <CardDescription>아직 검사 기록이 없습니다</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-12 text-gray-500">
            <p>검사를 시작하면 이곳에 기록이 표시됩니다</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>검사 이력</CardTitle>
              <CardDescription>총 {history.length}건의 검사 기록</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={exportToCSV}>
                <Download className="w-4 h-4 mr-2" />
                CSV 내보내기
              </Button>
              <Button variant="destructive" size="sm" onClick={onClearHistory}>
                <Trash2 className="w-4 h-4 mr-2" />
                전체 삭제
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px] pr-4">
            <div className="space-y-4">
              {history.map((item) => (
                <Card key={item.id} className={item.status === 'pass' ? 'border-green-200' : 'border-red-200'}>
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <div className="w-24 h-24 flex-shrink-0">
                        <img
                          src={item.imageUrl}
                          alt={item.imageName}
                          className="w-full h-full object-cover rounded"
                        />
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              {item.status === 'pass' ? (
                                <CheckCircle className="w-5 h-5 text-green-500" />
                              ) : (
                                <XCircle className="w-5 h-5 text-red-500" />
                              )}
                              <h3 className="font-semibold">{item.imageName}</h3>
                            </div>
                            <p className="text-sm text-gray-500">
                              {item.timestamp.toLocaleString('ko-KR')}
                            </p>
                          </div>
                          <Badge variant={item.status === 'pass' ? 'default' : 'destructive'}>
                            {item.status === 'pass' ? '합격' : '불합격'}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center gap-4 text-sm">
                          <span className="font-medium">점수: {item.overallScore}/100</span>
                          <span className="text-gray-600">
                            불량: {item.defects.length}건
                          </span>
                        </div>

                        {item.defects.length > 0 && (
                          <div className="flex flex-wrap gap-2">
                            {item.defects.map((defect, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {defect.name} ({defect.location})
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
