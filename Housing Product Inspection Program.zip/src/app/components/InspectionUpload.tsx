import { useState } from 'react';
import { Upload, Camera, AlertCircle, CheckCircle, XCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

interface DefectType {
  name: string;
  severity: 'high' | 'medium' | 'low';
  location: string;
  confidence: number;
}

interface InspectionResult {
  id: string;
  timestamp: Date;
  imageName: string;
  imageUrl: string;
  status: 'pass' | 'fail';
  defects: DefectType[];
  overallScore: number;
}

interface InspectionUploadProps {
  onInspectionComplete: (result: InspectionResult) => void;
}

export function InspectionUpload({ onInspectionComplete }: InspectionUploadProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imageName, setImageName] = useState<string>('');
  const [isInspecting, setIsInspecting] = useState(false);
  const [inspectionResult, setInspectionResult] = useState<InspectionResult | null>(null);
  const [progress, setProgress] = useState(0);

  const defectTypes = [
    { name: '크랙 (Crack)', location: ['상단 모서리', '측면', '하단부', '중앙부'] },
    { name: '스크래치 (Scratch)', location: ['표면', '측면', '코팅부'] },
    { name: '변형 (Deformation)', location: ['전체 구조', '모서리', '평면부'] },
    { name: '치수 불량 (Dimension)', location: ['길이', '너비', '두께', '직각도'] },
    { name: '표면 오염 (Contamination)', location: ['외부 표면', '내부 표면'] },
    { name: '기포 (Bubble)', location: ['코팅층', '재질 내부'] },
    { name: '색상 불균일 (Color Variation)', location: ['전체 표면', '부분 영역'] }
  ];

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setImageName(file.name);
        setInspectionResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const simulateInspection = () => {
    if (!selectedImage) return;

    setIsInspecting(true);
    setProgress(0);

    // 진행바 시뮬레이션
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 10;
      });
    }, 200);

    // 검사 시뮬레이션
    setTimeout(() => {
      const hasDefect = Math.random() > 0.4; // 60% 확률로 불량
      const numDefects = hasDefect ? Math.floor(Math.random() * 3) + 1 : 0;
      
      const detectedDefects: DefectType[] = [];
      const usedDefectTypes = new Set<number>();

      for (let i = 0; i < numDefects; i++) {
        let defectIndex;
        do {
          defectIndex = Math.floor(Math.random() * defectTypes.length);
        } while (usedDefectTypes.has(defectIndex));
        
        usedDefectTypes.add(defectIndex);
        const defect = defectTypes[defectIndex];
        const locationIndex = Math.floor(Math.random() * defect.location.length);
        
        const severities: ('high' | 'medium' | 'low')[] = ['high', 'medium', 'low'];
        const severity = severities[Math.floor(Math.random() * severities.length)];

        detectedDefects.push({
          name: defect.name,
          severity,
          location: defect.location[locationIndex],
          confidence: Math.floor(Math.random() * 15) + 85 // 85-100%
        });
      }

      const overallScore = hasDefect 
        ? Math.floor(Math.random() * 30) + 40 // 40-70점
        : Math.floor(Math.random() * 15) + 85; // 85-100점

      const result: InspectionResult = {
        id: Date.now().toString(),
        timestamp: new Date(),
        imageName,
        imageUrl: selectedImage,
        status: hasDefect ? 'fail' : 'pass',
        defects: detectedDefects,
        overallScore
      };

      setInspectionResult(result);
      setIsInspecting(false);
      onInspectionComplete(result);
    }, 2500);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getSeverityText = (severity: string) => {
    switch (severity) {
      case 'high': return '높음';
      case 'medium': return '중간';
      case 'low': return '낮음';
      default: return '알 수 없음';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>하우징 제품 이미지 업로드</CardTitle>
          <CardDescription>
            검사할 하우징 제품의 이미지를 업로드하세요
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-center w-full">
            <label className="flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 border-gray-300">
              {selectedImage ? (
                <div className="relative w-full h-full p-4">
                  <img
                    src={selectedImage}
                    alt="선택된 이미지"
                    className="w-full h-full object-contain"
                  />
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <Upload className="w-12 h-12 mb-4 text-gray-500" />
                  <p className="mb-2 text-sm text-gray-500">
                    <span className="font-semibold">클릭하여 업로드</span> 또는 드래그 앤 드롭
                  </p>
                  <p className="text-xs text-gray-500">PNG, JPG, JPEG (최대 10MB)</p>
                </div>
              )}
              <input
                type="file"
                className="hidden"
                accept="image/*"
                onChange={handleImageUpload}
              />
            </label>
          </div>

          {selectedImage && (
            <div className="flex gap-3">
              <Button
                onClick={simulateInspection}
                disabled={isInspecting}
                className="flex-1"
              >
                <Camera className="w-4 h-4 mr-2" />
                {isInspecting ? '검사 중...' : '불량 검사 시작'}
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setSelectedImage(null);
                  setInspectionResult(null);
                  setImageName('');
                }}
              >
                초기화
              </Button>
            </div>
          )}

          {isInspecting && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>AI 검사 진행 중...</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} />
            </div>
          )}
        </CardContent>
      </Card>

      {inspectionResult && (
        <Card className={inspectionResult.status === 'pass' ? 'border-green-500' : 'border-red-500'}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                {inspectionResult.status === 'pass' ? (
                  <>
                    <CheckCircle className="w-6 h-6 text-green-500" />
                    검사 합격
                  </>
                ) : (
                  <>
                    <XCircle className="w-6 h-6 text-red-500" />
                    검사 불합격
                  </>
                )}
              </CardTitle>
              <Badge variant={inspectionResult.status === 'pass' ? 'default' : 'destructive'}>
                점수: {inspectionResult.overallScore}/100
              </Badge>
            </div>
            <CardDescription>
              검사 일시: {inspectionResult.timestamp.toLocaleString('ko-KR')}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {inspectionResult.status === 'fail' && inspectionResult.defects.length > 0 && (
              <div className="space-y-3">
                <h3 className="font-semibold flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-red-500" />
                  검출된 불량 ({inspectionResult.defects.length}건)
                </h3>
                <div className="space-y-2">
                  {inspectionResult.defects.map((defect, index) => (
                    <div
                      key={index}
                      className="p-4 border rounded-lg bg-gray-50 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold">{defect.name}</span>
                        <Badge className={getSeverityColor(defect.severity)}>
                          심각도: {getSeverityText(defect.severity)}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600">
                        <p>위치: {defect.location}</p>
                        <p>신뢰도: {defect.confidence}%</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {inspectionResult.status === 'pass' && (
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-green-800">
                  ✓ 불량이 검출되지 않았습니다. 제품이 품질 기준을 충족합니다.
                </p>
              </div>
            )}

            <div className="pt-4 border-t">
              <h4 className="font-semibold mb-2">검사 요약</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">이미지:</span>
                  <p className="font-medium">{inspectionResult.imageName}</p>
                </div>
                <div>
                  <span className="text-gray-600">불량 개수:</span>
                  <p className="font-medium">{inspectionResult.defects.length}건</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
